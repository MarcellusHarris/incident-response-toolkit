## Incident Response Toolkit

`ir_collect.py` automates the collection of volatile forensic data during an incident response. It captures running processes, open network ports, and user information, then writes the results to a JSON bundle.

### Usage

- **Linux / macOS**
  ```bash
  python3 ir_collect.py --output /tmp/ir_bundle.json
  ```
- **Windows (PowerShell one‑liner)**
  ```powershell
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/your-org/incident-response-toolkit/main/ir_collect.py' -OutFile ir_collect.py; python ir_collect.py --output %TEMP%\ir_bundle.json"
  ```
- **macOS (curl)**
  ```bash
  curl -sSL https://raw.githubusercontent.com/your-org/incident-response-toolkit/main/ir_collect.py | python3 - --output /tmp/ir_bundle.json
  ```

The `examples/` folder contains a `sample-output.json` demonstrating the structure of a collection bundle. A minimal pytest (`tests/test_ir_collect.py`) verifies the presence of expected keys in the JSON output. Adapt the script as needed to collect additional artefacts or to support different operating systems.
