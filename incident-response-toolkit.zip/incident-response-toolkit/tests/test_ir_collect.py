import json
import os


def test_sample_output():
    """Ensure the sample output contains expected top‑level keys and types."""
    path = os.path.join(os.path.dirname(__file__), '..', 'examples', 'sample-output.json')
    with open(path) as f:
        data = json.load(f)
    assert 'timestamp' in data
    assert 'processes' in data and isinstance(data['processes'], list)
    assert 'open_ports' in data
    assert 'users' in data
