# Agent Playbook for Incident Response Toolkit

1. **Cross‑platform testing:** Test `ir_collect.py` on Windows, macOS and Linux to ensure it runs and collects expected artefacts. Update usage examples accordingly.
2. **Sample bundles:** Generate fresh sample output bundles after adding new collection modules and update `examples/` and tests.
3. **Tests:** Run the pytest suite in `tests/` to confirm that the collector outputs the required keys and formats.
4. **Documentation:** Keep the README up to date with one‑liner commands and expand instructions for additional artefacts (registry dumps, memory captures, etc.).
5. **Issues:** File issues for missing features, cross‑platform bugs or new forensic modules to collect.
