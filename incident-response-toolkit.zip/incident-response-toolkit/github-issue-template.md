### Incident Response Toolkit TODOs

Final steps to complete this project:

- [ ] **Cross‑platform examples:** Document one‑line commands for running `ir_collect.py` on Windows (PowerShell), macOS (via `curl` and Python), and Linux.
- [ ] **Sample output:** Provide a sample bundle in `/examples/` (`sample-output.json`) so users can see the expected structure.
- [ ] **Tests:** Add a minimal pytest (`tests/test_ir_collect.py`) to assert that the output contains required keys.
- [ ] **README enhancements:** Expand the usage section with these examples and encourage contributions for additional artefacts (registry dumps, memory dumps, etc.).
